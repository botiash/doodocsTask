package downloader

// Downloaders defines the downloader function to each sites
var Downloaders = map[string]interface{}{"instagram": downloadInstagram}
