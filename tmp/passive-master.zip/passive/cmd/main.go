package main

import "passive/internal/handler"

func main() {
	handler.Run()
}
